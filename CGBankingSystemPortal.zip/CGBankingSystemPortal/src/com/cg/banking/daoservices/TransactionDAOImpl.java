package com.cg.banking.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public class TransactionDAOImpl implements TransactionDAO{
	 EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");	
	@Override
	public Transaction save(Account account, Transaction transaction) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		transaction.setAccount(account);
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
			return transaction ;
	}

	@Override
	public Transaction findOne(int accountNumber, int transactionId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		return entityManager.find(Transaction.class,transactionId );
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Transaction> findAll(int accountNumber) {
		Query query=entityManagerFactory.createEntityManager().createQuery("from Transaction t",Transaction.class);
		return (List<Transaction>)query.getResultList();
	}
	
}
