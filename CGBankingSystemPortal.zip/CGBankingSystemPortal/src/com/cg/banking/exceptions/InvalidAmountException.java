package com.cg.banking.exceptions;
public class InvalidAmountException extends RuntimeException{
	public InvalidAmountException(){
		System.out.println("Invalid Amount");
	}
}
