package com.cg.banking.exceptions;
public class AccountNotFoundException extends RuntimeException {
	public AccountNotFoundException(){
		System.out.println("Account does not Exist");
	}
}
